import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {AuthService} from '../../services/auth.service';
import {CustomValidators} from 'ng2-validation';

const password = new FormControl('', Validators.required);
const confirmPassword = new FormControl('', CustomValidators.equalTo(password));
@Component({
  selector: 'app-change',
  templateUrl: './change.component.html',
  styleUrls: ['./change.component.scss']
})
export class ChangeComponent implements OnInit {
  public form: FormGroup;
  constructor(private fb: FormBuilder, private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.form = this.fb.group ( {
      password: password,
      confirmPassword: confirmPassword
    } );
  }
  onSubmit() {
    let changePasswordData = {
      uid : localStorage.getItem('userID'),
      password: this.form.controls.password.value
    }
    console.log(changePasswordData);
    this.authService.changePassword(changePasswordData)
      .then((response) => { console.log(response);})
      .catch((error) => {});
  }

}
