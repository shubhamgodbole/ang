import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blank',
  templateUrl: './blank.component.html',
  styleUrls: ['./blank.component.scss']
})
export class BlankComponent implements OnInit {
  show: boolean = false;
  constructor() { }

  ngOnInit() {
  }
  cl() {
  this.show = !this.show;
  }
}
