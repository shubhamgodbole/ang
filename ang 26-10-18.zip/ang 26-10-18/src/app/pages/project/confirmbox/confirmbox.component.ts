import {Component, Inject, OnInit, ViewContainerRef} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog} from '@angular/material';
import {ProjectService} from '../../../services/project.service';
import {ToastsManager} from 'ng2-toastr';

@Component({
  selector: 'app-confirmbox',
  templateUrl: './confirmbox.component.html',
  styleUrls: ['./confirmbox.component.scss']
})
export class ConfirmboxComponent implements OnInit {

  constructor(public dialog: MatDialog,
              private projectService: ProjectService,
              vcr: ViewContainerRef,
              public toastr: ToastsManager,
              @Inject(MAT_DIALOG_DATA) public data: any) {
    console.log('deleteModal', data);
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
  }
  cancle() {
    this.toastr.success('You are awesome!', 'Success!');
    this.dialog.closeAll();
  }
  delete() {
    this.projectService.deleteProject(this.data)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
      });
    this.dialog.closeAll();
  }
}
