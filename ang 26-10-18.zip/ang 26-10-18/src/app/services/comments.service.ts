import { Injectable } from '@angular/core';
import { ComandataService } from './comandata.service';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CommentsService {

  constructor(private http: HttpClient, public comandata: ComandataService) { }

  addNewCommnet(commentData): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      const apiUrl = this.comandata.apiUrl + 'comments/';
      this.http.post(apiUrl, commentData)
        .toPromise()
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          (error.status === 201) ? resolve('Subscribed successfully') : reject(error)
        });
    });
  }

  getAllCommnet(tid): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      const apiUrl = this.comandata.apiUrl + 'comments/' + tid;
      this.http.get(apiUrl)
        .toPromise()
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          (error.status === 201) ? resolve('Subscribed successfully') : reject(error)
        });
    });
  }
}
