import { Injectable } from '@angular/core';

@Injectable()
export class ComandataService {
   apiUrl = 'http://localhost:1212/api/';
}
