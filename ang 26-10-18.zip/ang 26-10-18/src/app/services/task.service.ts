import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ComandataService} from './comandata.service';

@Injectable()
export class TaskService {

  constructor(private http: HttpClient, private  comandata: ComandataService) { }

  addTask(taskData): Promise<any> {
    return new Promise<any>((resolve, reject) => {
     // const apiUrl = 'http://localhost:1234/api/task/';
      const apiUrl = this.comandata.apiUrl + 'task/';
      this.http.post(apiUrl, taskData)
        .toPromise()
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  showTask(): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      let userID = localStorage.getItem('userID');
      let projectID = localStorage.getItem('projectID');
     // const apiUrl = 'http://localhost:1234/api/task/' + projectID;
      const apiUrl = this.comandata.apiUrl + 'task/' + projectID;
      console.log(apiUrl);
      this.http.get(apiUrl)
        .toPromise()
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  editTask(taskData): Promise<any> {
    return new Promise<any>((resolve, reject) => {
     // const apiUrl = 'http://localhost:1234/api/task/';
      const apiUrl = this.comandata.apiUrl + 'task/';
      this.http.put(apiUrl, taskData)
        .toPromise()
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
}
